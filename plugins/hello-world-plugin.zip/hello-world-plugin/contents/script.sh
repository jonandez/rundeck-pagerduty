#!/bin/bash

echo "Hello bash from $1"